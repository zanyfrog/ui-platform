/** Structured lookup choices are opt-in; legacy comma options retain their format. */
export function selectOptions(legacy, structured) {
  if (structured === null || structured === undefined) return (legacy || '').split(',').map(s => s.trim()).filter(Boolean).map(value => ({ value, label: value }));
  try {
    const items = JSON.parse(structured);
    if (!Array.isArray(items) || items.some(o => !o || typeof o.value !== 'string' || typeof o.label !== 'string' || Object.keys(o).some(k => !['value', 'label', 'disabled'].includes(k)) || o.disabled !== undefined && typeof o.disabled !== 'boolean') || new Set(items.map(o => o.value)).size !== items.length) return [];
    return items;
  } catch { return []; }
}
